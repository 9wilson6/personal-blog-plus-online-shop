create view view_receipts as
select `pharm`.`tblpayments`.`receipt_no`   AS `receipt_no`,
       `pharm`.`tblpayments`.`patient_id`   AS `patient_id`,
       `pharm`.`tblpayments`.`charge_cost`  AS `charge_cost`,
       `pharm`.`tblpayments`.`payment_date` AS `payment_date`,
       `pharm`.`tblpayments`.`description`  AS `description`,
       `pharm`.`tblpatients`.`p_fname`      AS `p_fname`,
       `pharm`.`tblpatients`.`p_lname`      AS `p_lname`,
       `pharm`.`tblpatients`.`gender`       AS `gender`,
       `pharm`.`tblpatients`.`p_phone`      AS `p_phone`
from (`pharm`.`tblpayments`
       join `pharm`.`tblpatients`)
where (`pharm`.`tblpayments`.`patient_id` = `pharm`.`tblpatients`.`patient_id`);

