create view view_appointments as
select `pharm`.`tblappointments`.`visit_id`   AS `visit_id`,
       `pharm`.`tblappointments`.`status`     AS `status`,
       `pharm`.`tblappointments`.`patient_id` AS `patient_id`,
       `pharm`.`tblappointments`.`user_id`    AS `user_id`,
       `pharm`.`tblappointments`.`visit_date` AS `visit_date`,
       `pharm`.`tblstaff`.`staff_id`          AS `staff_id`,
       `pharm`.`tblstaff`.`staff_fname`       AS `staff_fname`,
       `pharm`.`tblstaff`.`staff_lname`       AS `staff_lname`,
       `pharm`.`tblstaff`.`staff_idno`        AS `staff_idno`,
       `pharm`.`tblstaff`.`staff_phone`       AS `staff_phone`,
       `pharm`.`tblpatients`.`p_fname`        AS `p_fname`,
       `pharm`.`tblpatients`.`p_lname`        AS `p_lname`,
       `pharm`.`tblpatients`.`user_id`        AS `acc_id`,
       `pharm`.`tblpatients`.`gender`         AS `gender`,
       `pharm`.`tblpatients`.`p_dob`          AS `p_dob`,
       `pharm`.`tblpatients`.`p_phone`        AS `p_phone`
from ((`pharm`.`tblappointments` join `pharm`.`tblstaff`)
       join `pharm`.`tblpatients`)
where ((`pharm`.`tblappointments`.`patient_id` = `pharm`.`tblpatients`.`patient_id`) and
       (`pharm`.`tblappointments`.`user_id` = `pharm`.`tblstaff`.`staff_no`));

