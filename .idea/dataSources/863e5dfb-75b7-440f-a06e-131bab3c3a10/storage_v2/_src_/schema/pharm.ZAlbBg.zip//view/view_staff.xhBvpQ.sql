create view view_staff as
select `pharm`.`tblusers`.`account_type` AS `account_type`,
       `pharm`.`tblusers`.`username`     AS `username`,
       `pharm`.`tblstaff`.`staff_id`     AS `staff_id`,
       `pharm`.`tblstaff`.`staff_no`     AS `staff_no`,
       `pharm`.`tblstaff`.`staff_fname`  AS `staff_fname`,
       `pharm`.`tblstaff`.`staff_lname`  AS `staff_lname`,
       `pharm`.`tblstaff`.`staff_idno`   AS `staff_idno`,
       `pharm`.`tblstaff`.`staff_phone`  AS `staff_phone`
from (`pharm`.`tblusers`
       join `pharm`.`tblstaff`)
where (`pharm`.`tblstaff`.`staff_no` = `pharm`.`tblusers`.`user_id`);

