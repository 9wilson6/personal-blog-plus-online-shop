create view view_diseases_reported as
select `pigs_db`.`pig_diseases`.`disease_id`  AS `disease_id`,
       `pigs_db`.`pig_diseases`.`farmer_id`   AS `farmer_id`,
       `pigs_db`.`pig_diseases`.`description` AS `description`,
       `pigs_db`.`pig_diseases`.`date_time`   AS `date_time`,
       `pigs_db`.`farmers_tbl`.`first_name`   AS `first_name`,
       `pigs_db`.`farmers_tbl`.`last_name`    AS `last_name`
from (`pigs_db`.`pig_diseases`
       join `pigs_db`.`farmers_tbl`)
where (`pigs_db`.`pig_diseases`.`farmer_id` = `pigs_db`.`farmers_tbl`.`farmer_id`);

