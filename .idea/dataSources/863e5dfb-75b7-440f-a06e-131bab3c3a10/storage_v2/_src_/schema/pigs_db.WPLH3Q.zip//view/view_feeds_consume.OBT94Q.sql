create view view_feeds_consume as
select `pigs_db`.`feeds_tbl`.`feeds_type`             AS `feeds_type`,
       `pigs_db`.`feeds_tbl`.`particular`             AS `particular`,
       `pigs_db`.`feeds_purchase_tbl`.`id`            AS `id`,
       `pigs_db`.`feeds_purchase_tbl`.`code`          AS `code`,
       `pigs_db`.`feeds_purchase_tbl`.`receipt_no`    AS `receipt_no`,
       `pigs_db`.`feeds_purchase_tbl`.`quantity`      AS `quantity`,
       `pigs_db`.`feeds_purchase_tbl`.`purchase_date` AS `purchase_date`,
       `pigs_db`.`feeds_purchase_tbl`.`cost`          AS `cost`,
       `pigs_db`.`feeds_purchase_tbl`.`farmer_id`     AS `farmer_id`
from (`pigs_db`.`feeds_tbl`
       join `pigs_db`.`feeds_purchase_tbl`)
where (`pigs_db`.`feeds_purchase_tbl`.`code` = `pigs_db`.`feeds_tbl`.`code`);

